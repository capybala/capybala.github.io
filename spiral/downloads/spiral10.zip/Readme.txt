﻿------------------------------------------------------------------
[  名称  ] Sπral Version 1.0
[ 制作者 ] Capybala.com
[ 配布元 ] http://capybala.com/ 
[ 連絡先 ] capybala@gmail.com
[ 著作権 ] Copyright (c) 2009 Capybala.com. All rights reserved.
------------------------------------------------------------------

□概要
Sπralは円周率を螺旋状に表示するスクリーンセーバーです。

□動作環境
Sπralの動作には.net Framework Version 2.0以上が必要です。
Windows Vistaには標準でインストールされています。

インストールされていない場合は、Windows Updateでインストールするか、
下記のURLからdotNetFx35setup.exeをダウンロードしてインストールしてください。
http://www.microsoft.com/downloads/details.aspx?FamilyID=333325FD-AE52-4E35-B531-508D977D32A6&displaylang=ja

対応OSはWindows Vista/XPです。
Windows 2000/Me/98でも動くかもしれません。
それ以前のWindowsでは動作しません。

□インストール方法
ダウンロードしたzipファイルをLhaplusなどの解凍ソフトで解凍し、
解凍して出来たSpiral.scrを右クリックし、メニューからインストールを選択して下さい。

□アンインストール方法
コントロールパネルのスクリーンセイバーの設定から、Sπral以外のスクリーンセイバーに変更した後、
インストール時に解凍して出来たフォルダごと削除して下さい。

□更新履歴
1.0: 2009/07/25
     公開開始

□著作権と免責事項
このソフトウェアの著作権はCapybala.comが所有しています。

このソフトウェアの使用または使用不可によって、いかなる問題が生じた場合でも著作者はその責任を負いません。
バージョンアップや不具合に対する対応の責任も負わないものとします。
この文書の内容およびソフトウェアの意匠、仕様は、予告なしに変更されることがあります。

□サードパーティ製のコンポーネント
・OpenTK
http://www.opentk.com/

OpenGLのラッパーとしてOpenTKを利用させていただきました。

ライセンス表示
---------------------------------
Copyright (c) 2006 - 2008 The Open Toolkit library.

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
---------------------------------

・GLSharp
一歩、二歩、散歩。
http://sky.geocities.jp/freakish_osprey/

OpenGLのクラスライブラリとしてGLSharpを使わせていただきました。
また、OpenGLの解説を参考にさせていただきました。
